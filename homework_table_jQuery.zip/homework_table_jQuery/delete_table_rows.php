<?php


if (!isset($_SESSION['index'])) {
	$_SESSION['index']=[0];
}
$index =	array_push($_SESSION['index'],  $_POST['index']);;
$index = intval($index);


if (!isset($index) || $index == null) {
	$index = 0;
}

require_once 'list.php';

if (key_exists($index, $result)&& $index !=0) {
	unset($result[$index]);
}

echo $index;
