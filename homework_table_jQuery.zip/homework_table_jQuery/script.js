$(document).ready(function(){
	$("#button").click(function(){
		var val1 = $('#pass').val();
	    var val2 = $('#user').val();
	    $.ajax({
	        type: 'POST',
	        url: 'php.php',
	        data: { pass: val1, user: val2 },
	        success: function(response) {
	           if(response){
	        	  $('#container1').hide(); 
	        	  $('#container2').show();
	           } else {
	        	   alert("Try username: 'pesho' and password: 123");
	           }
	        }
	    });
	});
}); 

$(document).ready(function(){
	$("#plus").click(function(){
		$('#container2').hide(); 
		$('#container3').show();
	});	
var counter = 1;	 
var table_data = {}; 
	$("#enter").click(function(){ 
		var inputs = [counter, $("#name_iput").val(), $("#q_iput").val(), $("#pr_iput").val() ];
		counter++;
		var rowData = [];
		var obj={};
	    obj.col1=$("#num_iput").val();
	    obj.col2=$("#name_iput").val()
	    obj.col3=$("#q_iput").val();
	    obj.col3=$("#pr_iput").val();
	    rowData.push(obj);
	    var trHTML = '<tr>';
			for (var i = 0; i < inputs.length; i++) {
				trHTML += '<td>' + inputs[i] + '</td>';
			}
			trHTML += '<td><button class="del">delete</button><button class="edit">edit</button></td>';
			trHTML += '</tr>';
			
			$('#myTable').append(trHTML); 
			var row;
			$.ajax({
	            type: 'POST',
	            url: 'list.php',
	            data: { row: rowData},
	        });
		 $('#container3').hide(); 
	   	 $('#container2').show();
	});
});

$(document).ready(function(){ 
    $("#myTable").on('click','.edit',function(){
         var currentRow=$(this).closest("tr"); 
         var col2=currentRow.find("td:eq(1)").text(); 
         var col3=currentRow.find("td:eq(2)").text(); 
         var col4=currentRow.find("td:eq(3)").text(); 
         $("#name_iput").value = col2;
         $("#q_iput").value = col3;
         $("#pr_iput").value = col4;
	         $("#enter").click(function(){
	        	currentRow.remove();
	        	--counter; 
	     	});
         $('#container2').hide(); 
	   	 $('#container3').show();
    });
});
var index_num = 0;

$(document).ready(function(){
	$("#myTable").on('click', '.del', function () {
		var current = $(this).closest("tr"); 
		index_num = current.find("td:eq(0)").text(); 
		index_num = parseInt(index_num);
		console.log(index_num);
	    $(this).closest('tr').remove();
		    $.ajax({
	            type: 'POST',
	            url: 'delete_table_rows.php',
	            data: {index: index_num}, 
	        });
	});
});


