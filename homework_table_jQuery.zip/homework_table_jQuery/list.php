<?php
session_start();

if (!isset($_SESSION['row_data'])) {
	$_SESSION['row_data']=[0];
}
 array_push($_SESSION['row_data'],  $_POST['row']);
 
 $result = $_SESSION['row_data'];
 
 
 echo print_r($result);