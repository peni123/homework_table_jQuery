$("button").click(function(){
    $("div").animate({
        height: 'toggle'
    });
}); 

