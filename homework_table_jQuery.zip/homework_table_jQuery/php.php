<?php

$verify_user = "pesho";
$verify_pass = "123";

$pass = $_POST['pass'];
$user = $_POST['user'];

$proceed =  false;

if ($verify_user == $user && $verify_pass == $pass) {
	$proceed = true;
	echo $proceed;
} else {
	$proceed = false;
	echo $proceed;
}


